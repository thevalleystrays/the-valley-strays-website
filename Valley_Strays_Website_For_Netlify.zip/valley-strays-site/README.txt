THE VALLEY STRAYS WEBSITE — DRAFT

Open index.html in a browser to preview the site.

The assets folder contains the supplied band logo and black-and-white band portrait.
The Watch & Listen section embeds the three supplied YouTube videos. The embeds use YouTube's privacy-enhanced domain and have direct YouTube links underneath as a fallback.
The Gallery includes five Instagram post/reel embeds supplied by the band. Instagram embeds require an internet connection, a public/embeddable post, and Instagram's embed service to be available. Each embed also includes a direct Instagram link as a fallback.

The site is a responsive static HTML/CSS website. The gigs section is currently a placeholder and can be updated with confirmed dates. YouTube channel, Facebook, Instagram and booking email links are included.

Preferred domain: thevalleystrays.co.uk (not yet registered or connected).
Booking email: thevalleystrays@gmail.com
